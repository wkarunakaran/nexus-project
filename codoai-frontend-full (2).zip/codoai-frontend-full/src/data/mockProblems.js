export const LANGUAGES = ["python", "java", "cpp"];

export const MOCK_PROBLEMS = [
  {
    id: 1,
    title: "Sum of Two Numbers",
    difficulty: "Easy",
    topics: ["basics", "I/O"],
    videoUrl: "https://example.com/video/sum-two-numbers",
    referenceCode: {
      python: `def sum_two_numbers(a, b):
    return a + b

if __name__ == "__main__":
    x = int(input())
    y = int(input())
    print(sum_two_numbers(x, y))`,
      java: `import java.util.*;

public class Main {
    public static int sumTwoNumbers(int a, int b) {
        return a + b;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int x = sc.nextInt();
        int y = sc.nextInt();
        System.out.println(sumTwoNumbers(x, y));
    }
}`,
      cpp: `#include <bits/stdc++.h>
using namespace std;

int sum_two_numbers(int a, int b) {
    return a + b;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int x, y;
    cin >> x >> y;
    cout << sum_two_numbers(x, y) << "\n";
    return 0;
}`
    },
    explanations: {
      python: [
        "Line 1: Define a function that takes two parameters a and b.",
        "Line 2: Return the sum of a and b.",
        "Line 4: Check if this file is run as main script.",
        "Lines 5-7: Read two integers from input and print their sum."
      ],
      java: [
        "Line 1: Import utility package for Scanner.",
        "Line 3: Declare Main class.",
        "Lines 4-6: Define sumTwoNumbers method that returns a + b.",
        "Lines 7-14: Read two integers, compute the sum, and print it."
      ],
      cpp: [
        "Line 1: Include all standard headers using bits/stdc++.h (for simplicity).",
        "Lines 3-5: Define a function that returns the sum of two integers.",
        "Lines 7-14: Use fast I/O, read two integers, print their sum with a newline."
      ]
    },
    sampleTests: [
      { id: 1, input: "2\n3", expected: "5" },
      { id: 2, input: "10\n-4", expected: "6" }
    ]
  },
  {
    id: 2,
    title: "Maximum of Three Numbers",
    difficulty: "Easy",
    topics: ["conditionals"],
    videoUrl: "https://example.com/video/max-three",
    referenceCode: {
      python: `def max_of_three(a, b, c):
    return max(a, b, c)

if __name__ == "__main__":
    a = int(input())
    b = int(input())
    c = int(input())
    print(max_of_three(a, b, c))`,
      java: `import java.util.*;

public class Main {
    public static int maxOfThree(int a, int b, int c) {
        int max = a;
        if (b > max) max = b;
        if (c > max) max = c;
        return max;
    }
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);
        int a = sc.nextInt();
        int b = sc.nextInt();
        int c = sc.nextInt();
        System.out.println(maxOfThree(a, b, c));
    }
}`,
      cpp: `#include <bits/stdc++.h>
using namespace std;

int max_of_three(int a, int b, int c) {
    int maxv = a;
    if (b > maxv) maxv = b;
    if (c > maxv) maxv = c;
    return maxv;
}

int main() {
    ios::sync_with_stdio(false);
    cin.tie(nullptr);
    int a, b, c;
    cin >> a >> b >> c;
    cout << max_of_three(a, b, c) << "\n";
    return 0;
}`
    },
    explanations: {
      python: [
        "Line 1: Define a function that takes three integers.",
        "Line 2: Use built-in max to return the largest value.",
        "Lines 4-8: Read three integers and print the maximum."
      ],
      java: [
        "Lines 3-9: Calculate the maximum using if statements.",
        "Lines 10-17: Read three integers, print maximum."
      ],
      cpp: [
        "Lines 3-9: Determine maximum using simple comparisons.",
        "Lines 11-16: Read three integers and print maximum."
      ]
    },
    sampleTests: [
      { id: 1, input: "1 2 3", expected: "3" },
      { id: 2, input: "10 5 7", expected: "10" }
    ]
  }
];
