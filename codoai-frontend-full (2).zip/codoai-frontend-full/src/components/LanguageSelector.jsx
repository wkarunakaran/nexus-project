import React from "react";
import { LANGUAGES } from "../data/mockProblems";

const LABELS = {
  python: "Python",
  java: "Java",
  cpp: "C++"
};

export default function LanguageSelector({ current, onChange }) {
  return (
    <div className="lang-toggle">
      {LANGUAGES.map((lang) => (
        <button
          key={lang}
          onClick={() => onChange(lang)}
          className={"lang-pill" + (current === lang ? " active" : "")}
        >
          {LABELS[lang] || lang.toUpperCase()}
        </button>
      ))}
    </div>
  );
}
