import React from "react";
import ProgressBar from "./ProgressBar";

function ReferenceCode({ code }) {
  return (
    <div className="reference-block">
      <div className="reference-header">
        <span>Reference solution (read-only)</span>
        <span>Copy is disabled – type it manually</span>
      </div>
      <pre
        className="reference-code"
        style={{ userSelect: "none", pointerEvents: "none" }}
      >
        {code}
      </pre>
    </div>
  );
}

function ExplanationList({ explanations }) {
  return (
    <div className="explanation-block explanation-below">
      <div className="explanation-header">Line-by-line explanation</div>
      <div className="explanation-list">
        {explanations.map((exp, idx) => (
          <div key={idx} className="explanation-item">
            <div className="explanation-index">{idx + 1}</div>
            <p>{exp}</p>
          </div>
        ))}
      </div>
    </div>
  );
}

function DebugErrorPanel({ codeLength, referenceLength }) {
  const totalErrors = 3;
  const progressRatio = referenceLength
    ? Math.min(codeLength / referenceLength, 1)
    : 0;
  const fixedErrors = Math.round(progressRatio * totalErrors);
  const remainingErrors = Math.max(totalErrors - fixedErrors, 0);

  return (
    <div className="debug-panel">
      <div className="debug-header">
        <span>Debug status</span>
      </div>
      <div className="debug-stats">
        <div>
          <span>Total errors:</span>
          <strong>{totalErrors}</strong>
        </div>
        <div>
          <span>Fixed so far:</span>
          <strong>{fixedErrors}</strong>
        </div>
        <div>
          <span>Remaining:</span>
          <strong>{remainingErrors}</strong>
        </div>
      </div>
      <p className="debug-note">
        As you correct the code, this panel updates to show how many mistakes you
        have likely fixed.
      </p>
    </div>
  );
}

function AIRecommendations({ language, elapsedSeconds, progress }) {
  const steps = Math.floor((elapsedSeconds || 0) / 120);
  const baseTips = [
    "Start by writing the function signature and main input/output structure.",
    "Check you have handled reading all required inputs before doing any logic.",
    "Think about edge cases: zero, negatives, large values.",
    "Use simple, clear variable names so you can remember the logic later."
  ];

  if (language === "java") {
    baseTips.push(
      "Remember class Main and the public static void main(String[] args) entry point."
    );
  }
  if (language === "cpp") {
    baseTips.push(
      "Use std::cin and std::cout, and remember to end lines with \n."
    );
  }
  if (language === "python") {
    baseTips.push("Keep indentation consistent; avoid mixing tabs and spaces.");
  }

  const effectiveProgress = progress || 0;
  const progressBasedHint =
    effectiveProgress < 30
      ? "You've spent some time, but the code is still short. Try outlining comments for each step, then fill them with code."
      : effectiveProgress < 70
      ? "Good progress! Now double-check loops and conditions to match the logic from the video."
      : "You're close to the full solution. Focus on small details like off-by-one errors and exact output format.";

  const tipsToShow = baseTips.slice(0, Math.min(1 + steps, baseTips.length));

  return (
    <div className="ai-panel">
      <div className="ai-header">
        <span>AI Recommendations</span>
        <span>{(elapsedSeconds || 0).toFixed(0)}s elapsed</span>
      </div>
      <ul className="ai-list">
        {tipsToShow.map((t, idx) => (
          <li key={idx}>{t}</li>
        ))}
      </ul>
      <p className="ai-footer">{progressBasedHint}</p>
    </div>
  );
}

export default function RoundContent({
  round,
  referenceCode,
  explanations,
  sampleTests,
  code,
  onCodeChange,
  onSubmit,
  timeTaken,
  overallTime,
  isCompleted,
  language
}) {
  const labelMap = {
    1: "Round 1 – Type from reference",
    2: "Round 2 – Debug the code",
    3: "Round 3 – Blind typing (no reference)",
    4: "Round 4 – Test cases & final submission"
  };

  const descriptionMap = {
    1: "Manually type the code by looking at the reference solution. Copy/paste is disabled.",
    2: "Fix the mistakes in this code. You see only your code and a live error counter.",
    3: "Now type the full solution from memory without seeing the reference.",
    4: "Run your code against sample test cases. Passing all marks completion."
  };

  const showReference = round === 1;

  const handleSubmitClick = () => {
    if (!code.trim()) {
      alert("Please type some code before submitting this round.");
      return;
    }
    onSubmit();
  };

  let roundProgress = 0;
  if (referenceCode && (round === 1 || round === 3)) {
    roundProgress = Math.min(100, (code.length / referenceCode.length) * 100);
  } else if (round === 2) {
    roundProgress = isCompleted ? 100 : 30;
  } else if (round === 4) {
    roundProgress = isCompleted ? 100 : 50;
  }

  const elapsedSeconds = timeTaken ?? 0;

  return (
    <div className="round-wrapper">
      <div className="round-header">
        <div>
          <div className="round-title">{labelMap[round]}</div>
          <div className="round-subtitle">{descriptionMap[round]}</div>
        </div>
        <div className="round-progress">
          <ProgressBar label="Round progress" value={roundProgress} />
          <div className="round-time">
            Round time: {elapsedSeconds.toFixed(1)}s • Overall:{" "}
            {overallTime.toFixed(1)}s
          </div>
        </div>
      </div>

      {round === 1 ? (
        <>
          <div className="round-body equal-split">
            <div className="round-left">
              <div className="editor-header">
                <span>Your code ({language.toUpperCase()})</span>
                {isCompleted && (
                  <span className="completed-pill">Round completed ✓</span>
                )}
              </div>
              <textarea
                className="code-editor"
                value={code}
                onChange={(e) => onCodeChange(e.target.value)}
                placeholder="// Start typing your code here..."
              />
            </div>
            <div className="round-right">
              {showReference && <ReferenceCode code={referenceCode} />}
            </div>
          </div>
          <ExplanationList explanations={explanations} />
        </>
      ) : (
        <div className="round-body">
          <div className="round-left">
            <div className="editor-header">
              <span>Your code ({language.toUpperCase()})</span>
              {isCompleted && (
                <span className="completed-pill">Round completed ✓</span>
              )}
            </div>
            <textarea
              className="code-editor"
              value={code}
              onChange={(e) => onCodeChange(e.target.value)}
              placeholder={
                round === 3
                  ? "// Type the solution from memory here..."
                  : "// Start typing your code here..."
              }
            />
            {round === 3 && (
              <AIRecommendations
                language={language}
                elapsedSeconds={elapsedSeconds}
                progress={roundProgress}
              />
            )}
            {round === 2 && (
              <DebugErrorPanel
                codeLength={code.length}
                referenceLength={referenceCode ? referenceCode.length : 0}
              />
            )}
          </div>
          <div className="round-right">
            {round !== 2 && <ExplanationList explanations={explanations} />}
            {round === 4 && (
              <div className="tests-block">
                <div className="tests-header">
                  <span>Sample test cases</span>
                  <span>Hidden tests will also run in real judge</span>
                </div>
                <div className="tests-list">
                  {sampleTests.map((t) => (
                    <div key={t.id} className="test-item">
                      <div className="test-title">Test {t.id}</div>
                      <div className="test-line">
                        <span>Input:</span> <code>{t.input}</code>
                      </div>
                      <div className="test-line">
                        <span>Expected:</span> <code>{t.expected}</code>
                      </div>
                    </div>
                  ))}
                </div>
              </div>
            )}
          </div>
        </div>
      )}

      <div className="round-footer">
        <span className="round-note">
          In the full platform, your code will be compiled &amp; executed in a
          secure sandbox.
        </span>
        <button className="primary-btn" onClick={handleSubmitClick}>
          {round === 4 ? "Submit final answer" : "Submit round"}
        </button>
      </div>
    </div>
  );
}
