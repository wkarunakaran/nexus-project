import React from "react";
import { useNavigate } from "react-router-dom";
import ProgressBar from "./ProgressBar";

export default function ProblemList({ problems, attempts, currentLanguage }) {
  const navigate = useNavigate();

  return (
    <div className="card">
      <div className="card-header">
        <h2 className="card-title">All problems</h2>
        <p className="card-subtitle">
          Practice from basics to advanced in {currentLanguage.toUpperCase()}.
        </p>
      </div>
      <div className="problem-list">
        {problems.map((p) => {
          const key = `${p.id}_${currentLanguage}`;
          const attempt = attempts[key];
          const roundsCompleted = attempt
            ? Object.values(attempt.roundCompleted || {}).filter(Boolean).length
            : 0;
          const overallProgress = (roundsCompleted / 4) * 100;
          const completed = attempt?.finalCompleted;

          return (
            <button
              key={p.id}
              className="problem-card"
              onClick={() => navigate(`/problems/${p.id}`)}
            >
              <div className="problem-main">
                <div>
                  <h3 className="problem-title">{p.title}</h3>
                  <div className="problem-meta-row">
                    <span className={`difficulty ${p.difficulty.toLowerCase()}`}>
                      {p.difficulty}
                    </span>
                    <span className="chip">
                      Lang: {currentLanguage.toUpperCase()}
                    </span>
                    {p.topics.map((t) => (
                      <span key={t} className="chip subtle">
                        {t}
                      </span>
                    ))}
                  </div>
                </div>
                <div className="problem-progress">
                  <ProgressBar value={overallProgress} />
                  <span className="progress-status">
                    {completed ? "Completed ✓" : "In progress"}
                  </span>
                </div>
              </div>
            </button>
          );
        })}
      </div>
    </div>
  );
}
