import React from "react";

export default function ProgressBar({ label, value }) {
  const clamped = Math.max(0, Math.min(value ?? 0, 100));
  return (
    <div className="progress-wrapper">
      {label && (
        <div className="progress-header">
          <span className="progress-label">{label}</span>
          <span className="progress-value">{clamped.toFixed(0)}%</span>
        </div>
      )}
      <div className="progress-track">
        <div className="progress-fill" style={{ width: `${clamped}%` }} />
      </div>
    </div>
  );
}
