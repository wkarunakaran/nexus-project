import React from "react";
import { Link, NavLink } from "react-router-dom";

export default function Navbar({ user }) {
  return (
    <header className="navbar">
      <div className="navbar-left">
        <Link to="/" className="brand">
          <div className="brand-logo">cA</div>
          <div className="brand-text">
            <span className="brand-title">codoAI</span>
            <span className="brand-subtitle">Type • Debug • Blind • Test</span>
          </div>
        </Link>
      </div>
      <nav className="navbar-center">
        <NavLink to="/dashboard" className="nav-link">
          Dashboard
        </NavLink>
        <NavLink to="/problems" className="nav-link">
          Problems
        </NavLink>
        <NavLink to="/profile" className="nav-link">
          Profile
        </NavLink>
        {user?.isAdmin && (
          <NavLink to="/admin" className="nav-link">
            Admin
          </NavLink>
        )}
      </nav>
      <div className="navbar-right">
        {user ? (
          <div className="user-pill">
            <div className="user-avatar">
              {user.name ? user.name[0]?.toUpperCase() : "U"}
            </div>
            <div className="user-info">
              <span className="user-name">{user.name}</span>
              <span className="user-meta">
                {user.level} • {user.preferredLanguage.toUpperCase()}
              </span>
            </div>
          </div>
        ) : (
          <Link to="/login" className="primary-btn small">
            Login
          </Link>
        )}
      </div>
    </header>
  );
}
