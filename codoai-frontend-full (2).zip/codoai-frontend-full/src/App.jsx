import React, { useState, useEffect } from "react";
import { Routes, Route, Navigate, useLocation } from "react-router-dom";
import Navbar from "./components/Navbar";
import Landing from "./pages/Landing";
import ProfileSetup from "./pages/ProfileSetup";
import Dashboard from "./pages/Dashboard";
import ProblemsIndex from "./pages/ProblemsIndex";
import ProblemWorkspace from "./pages/ProblemWorkspace";
import Profile from "./pages/Profile";
import NotFound from "./pages/NotFound";
import Login from "./pages/Login";
import AdminPanel from "./pages/AdminPanel";
import { MOCK_PROBLEMS } from "./data/mockProblems";
import LanguageSelector from "./components/LanguageSelector";

const STORAGE_KEY = "codoai_state_v1";

function Layout({
  user,
  setUser,
  attempts,
  setAttempts,
  currentLanguage,
  setCurrentLanguage,
  problems,
  setProblems
}) {
  const location = useLocation();
  const hideNav =
    location.pathname === "/login" || location.pathname === "/profile-setup";

  return (
    <div className="app-root">
      {!hideNav && <Navbar user={user} />}
      {!hideNav && (
        <div className="top-right-lang">
          <LanguageSelector
            current={currentLanguage}
            onChange={setCurrentLanguage}
          />
        </div>
      )}
      <Routes>
        <Route path="/" element={<Landing />} />
        <Route path="/login" element={<Login onLogin={setUser} />} />
        <Route
          path="/profile-setup"
          element={
            user ? (
              <ProfileSetup onComplete={setUser} existing={user} />
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/dashboard"
          element={
            user ? (
              <Dashboard
                user={user}
                problems={problems}
                attempts={attempts}
                currentLanguage={currentLanguage}
              />
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/problems"
          element={
            user ? (
              <ProblemsIndex
                problems={problems}
                attempts={attempts}
                currentLanguage={currentLanguage}
              />
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/problems/:id"
          element={
            user ? (
              <ProblemWorkspace
                problems={problems}
                attempts={attempts}
                setAttempts={setAttempts}
                currentLanguage={currentLanguage}
                user={user}
              />
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/profile"
          element={
            user ? (
              <Profile
                user={user}
                attempts={attempts}
                problems={problems}
                currentLanguage={currentLanguage}
              />
            ) : (
              <Navigate to="/login" replace />
            )
          }
        />
        <Route
          path="/admin"
          element={
            user?.isAdmin ? (
              <AdminPanel problems={problems} setProblems={setProblems} />
            ) : (
              <Navigate to="/dashboard" replace />
            )
          }
        />
        <Route path="*" element={<NotFound />} />
      </Routes>
    </div>
  );
}

export default function App() {
  const [user, setUser] = useState(null);
  const [attempts, setAttempts] = useState({});
  const [currentLanguage, setCurrentLanguage] = useState("python");
  const [problems, setProblems] = useState(MOCK_PROBLEMS);

  // Load from localStorage on mount
  useEffect(() => {
    try {
      const raw = localStorage.getItem(STORAGE_KEY);
      if (!raw) return;
      const parsed = JSON.parse(raw);
      if (parsed.user) setUser(parsed.user);
      if (parsed.attempts) setAttempts(parsed.attempts);
      if (parsed.currentLanguage) setCurrentLanguage(parsed.currentLanguage);
      if (parsed.problems && parsed.problems.length) setProblems(parsed.problems);
    } catch (e) {
      console.error("Failed to parse saved state", e);
    }
  }, []);

  // Persist to localStorage when key pieces change
  useEffect(() => {
    const payload = {
      user,
      attempts,
      currentLanguage,
      problems
    };
    try {
      localStorage.setItem(STORAGE_KEY, JSON.stringify(payload));
    } catch (e) {
      console.error("Failed to persist state", e);
    }
  }, [user, attempts, currentLanguage, problems]);

  return (
    <Layout
      user={user}
      setUser={setUser}
      attempts={attempts}
      setAttempts={setAttempts}
      currentLanguage={currentLanguage}
      setCurrentLanguage={setCurrentLanguage}
      problems={problems}
      setProblems={setProblems}
    />
  );
}
