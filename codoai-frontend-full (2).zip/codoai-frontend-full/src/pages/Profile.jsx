import React from "react";
import ProgressBar from "../components/ProgressBar";

export default function Profile({ user, attempts, problems, currentLanguage }) {
  const totalProblems = problems.length;
  const completedCount = problems.filter((p) => {
    const key = `${p.id}_${currentLanguage}`;
    return attempts[key]?.finalCompleted;
  }).length;

  const totalTime = Object.values(attempts).reduce(
    (sum, a) => sum + (a.totalTimeSeconds || 0),
    0
  );

  return (
    <div className="page">
      <div className="card profile-header">
        <div className="profile-main">
          <div className="profile-avatar">
            {user?.name ? user.name[0]?.toUpperCase() : "U"}
          </div>
          <div>
            <h1 className="profile-name">{user?.name || "Your profile"}</h1>
            <p className="profile-meta">
              Level: <strong>{user?.level}</strong> • Preferred:{" "}
              <strong>{user?.preferredLanguage.toUpperCase()}</strong>
            </p>
          </div>
        </div>
        <div className="profile-summary">
          <div className="summary-item">
            <span>Problems completed ({currentLanguage.toUpperCase()})</span>
            <strong>
              {completedCount} / {totalProblems}
            </strong>
            <ProgressBar
              value={totalProblems ? (completedCount / totalProblems) * 100 : 0}
            />
          </div>
          <div className="summary-item">
            <span>Total time spent (all languages)</span>
            <strong>{totalTime.toFixed(1)}s</strong>
            <p className="summary-note">
              Time is tracked per round once you start typing, and added for all attempts.
            </p>
          </div>
        </div>
      </div>

      <div className="card">
        <h2 className="card-title">
          Per-problem progress ({currentLanguage.toUpperCase()})
        </h2>
        <div className="profile-problem-list">
          {problems.map((p) => {
            const key = `${p.id}_${currentLanguage}`;
            const attempt = attempts[key];
            const roundsCompleted = attempt
              ? Object.values(attempt.roundCompleted || {}).filter(Boolean).length
              : 0;
            const progress = (roundsCompleted / 4) * 100;

            return (
              <div key={p.id} className="profile-problem-item">
                <div>
                  <div className="profile-problem-title">{p.title}</div>
                  <div className="profile-problem-meta">
                    Difficulty:{" "}
                    <span className={`difficulty ${p.difficulty.toLowerCase()}`}>
                      {p.difficulty}
                    </span>
                  </div>
                </div>
                <div className="profile-problem-right">
                  <ProgressBar value={progress} />
                  <span className="progress-status">
                    {attempt?.finalCompleted ? "Completed ✓" : "In progress"}
                  </span>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}
