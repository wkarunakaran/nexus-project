import React, { useMemo, useState, useEffect } from "react";
import { useParams } from "react-router-dom";
import RoundContent from "../components/RoundContent";
import ProgressBar from "../components/ProgressBar";

export default function ProblemWorkspace({
  problems,
  attempts,
  setAttempts,
  currentLanguage,
  user
}) {
  const { id } = useParams();
  const problemId = Number(id);
  const problem = useMemo(
    () => problems.find((p) => p.id === problemId),
    [problemId, problems]
  );

  const [currentRound, setCurrentRound] = useState(1);
  const [roundState, setRoundState] = useState({
    1: { code: "", completed: false, time: 0 },
    2: { code: "", completed: false, time: 0 },
    3: { code: "", completed: false, time: 0 },
    4: { code: "", completed: false, time: 0 }
  });
  const [roundStartTimes, setRoundStartTimes] = useState({});
  const [globalStartTime, setGlobalStartTime] = useState(null);
  const [now, setNow] = useState(Date.now());

  const key = `${problemId}_${currentLanguage}`;
  const existingAttempt = attempts[key];

  useEffect(() => {
    if (existingAttempt) {
      setRoundState(existingAttempt.roundState || roundState);
      setCurrentRound(existingAttempt.lastRound || 1);
      setGlobalStartTime(existingAttempt.globalStartTime || null);
    } else {
      setRoundState({
        1: { code: "", completed: false, time: 0 },
        2: { code: "", completed: false, time: 0 },
        3: { code: "", completed: false, time: 0 },
        4: { code: "", completed: false, time: 0 }
      });
      setCurrentRound(1);
      setGlobalStartTime(null);
    }
    setRoundStartTimes({});
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, [problemId, currentLanguage]);

  useEffect(() => {
    const id = setInterval(() => {
      setNow(Date.now());
    }, 1000);
    return () => clearInterval(id);
  }, []);

  const handleCodeChange = (value) => {
    setRoundState((prev) => ({
      ...prev,
      [currentRound]: { ...prev[currentRound], code: value }
    }));
    if (!roundStartTimes[currentRound]) {
      const ts = Date.now();
      setRoundStartTimes((prev) => ({
        ...prev,
        [currentRound]: ts
      }));
      if (!globalStartTime) {
        setGlobalStartTime(ts);
      }
    }
  };

  const handleSubmitRound = () => {
    const tsNow = Date.now();
    const roundStart = roundStartTimes[currentRound] || tsNow;
    const elapsedSeconds = (tsNow - roundStart) / 1000;

    setRoundState((prev) => ({
      ...prev,
      [currentRound]: {
        ...prev[currentRound],
        completed: true,
        time: elapsedSeconds
      }
    }));

    setAttempts((prev) => {
      const prevAttempt = prev[key] || {
        roundCompleted: {},
        roundState: {},
        finalCompleted: false,
        totalTimeSeconds: 0,
        globalStartTime: globalStartTime || roundStart
      };
      const newRoundCompleted = {
        ...prevAttempt.roundCompleted,
        [currentRound]: true
      };
      const newRoundState = {
        ...prevAttempt.roundState,
        [currentRound]: {
          ...roundState[currentRound],
          completed: true,
          time: elapsedSeconds
        }
      };

      const completedTotal = Object.values(newRoundState).reduce(
        (sum, r) => sum + (r.time || 0),
        0
      );

      const allRoundsDone =
        newRoundCompleted[1] &&
        newRoundCompleted[2] &&
        newRoundCompleted[3] &&
        newRoundCompleted[4];
      const finalCompleted =
        currentRound === 4 ? Boolean(allRoundsDone) : prevAttempt.finalCompleted;

      if (finalCompleted && !prevAttempt.finalCompleted) {
        alert(
          `Problem "${problem.title}" completed in ${completedTotal.toFixed(
            1
          )}s (${currentLanguage.toUpperCase()}).`
        );
      }

      return {
        ...prev,
        [key]: {
          ...prevAttempt,
          roundCompleted: newRoundCompleted,
          roundState: newRoundState,
          totalTimeSeconds: completedTotal,
          finalCompleted,
          lastRound: currentRound,
          globalStartTime: prevAttempt.globalStartTime || globalStartTime || roundStart
        }
      };
    });

    if (currentRound < 4) {
      setCurrentRound((r) => r + 1);
    }
  };

  if (!problem) {
    return (
      <div className="page">
        <div className="card">
          <h1>Problem not found</h1>
          <p>Please go back and select a valid problem.</p>
        </div>
      </div>
    );
  }

  const attempt = attempts[key];
  const roundsCompletedCount = attempt
    ? Object.values(attempt.roundCompleted || {}).filter(Boolean).length
    : 0;
  const overallProgress = (roundsCompletedCount / 4) * 100;

  const currentRoundState = roundState[currentRound];
  const currentRoundStart = roundStartTimes[currentRound];
  let liveRoundTime = currentRoundState.time || 0;
  if (!currentRoundState.completed && currentRoundStart) {
    liveRoundTime = (now - currentRoundStart) / 1000;
  }

  let overallTime = 0;
  for (let r = 1; r <= 4; r++) {
    if (r === currentRound && !roundState[r].completed && roundStartTimes[r]) {
      overallTime += (now - roundStartTimes[r]) / 1000;
    } else {
      overallTime += roundState[r].time || 0;
    }
  }

  const refCode = problem.referenceCode[currentLanguage];
  const explanations = problem.explanations[currentLanguage];

  const leaderboardEntries = [];
  if (attempt?.finalCompleted) {
    leaderboardEntries.push({
      name: user?.name || "You",
      time: attempt.totalTimeSeconds || overallTime
    });
  }
  leaderboardEntries.sort((a, b) => a.time - b.time);

  return (
    <div className="page">
      <div className="card problem-header-card">
        <div>
          <h1 className="problem-main-title">{problem.title}</h1>
          <p className="problem-subtitle">
            Problem ID: <strong>#{problem.id}</strong> • Difficulty:{" "}
            <span className={`difficulty ${problem.difficulty.toLowerCase()}`}>
              {problem.difficulty}
            </span>{" "}
            • Language: <strong>{currentLanguage.toUpperCase()}</strong>
          </p>
          <p className="problem-subtitle">
            Topics: {problem.topics.join(", ")} •{" "}
            <a href={problem.videoUrl} target="_blank" rel="noreferrer">
              Watch learning video ↗
            </a>
          </p>
        </div>
        <div className="problem-header-right">
          <ProgressBar label="Overall progress" value={overallProgress} />
          <div className="round-selector">
            {[1, 2, 3, 4].map((r) => (
              <button
                key={r}
                onClick={() => setCurrentRound(r)}
                className={
                  "round-chip" +
                  (currentRound === r ? " active" : "") +
                  (attempt?.roundCompleted?.[r] ? " done" : "")
                }
              >
                R{r}
              </button>
            ))}
          </div>
          <div className="problem-status">
            Status:{" "}
            {attempt?.finalCompleted ? (
              <span className="status-done">Completed ✓</span>
            ) : (
              <span className="status-progress">In progress</span>
            )}
          </div>
          <div className="problem-status" style={{ marginTop: "0.15rem" }}>
            Overall time: <strong>{overallTime.toFixed(1)}s</strong>
          </div>
        </div>
      </div>
      <div className="card">
        <RoundContent
          round={currentRound}
          referenceCode={refCode}
          explanations={explanations}
          sampleTests={problem.sampleTests}
          code={roundState[currentRound].code}
          onCodeChange={handleCodeChange}
          onSubmit={handleSubmitRound}
          timeTaken={liveRoundTime}
          overallTime={overallTime}
          isCompleted={roundState[currentRound].completed}
          language={currentLanguage}
        />
      </div>
      <div className="card" style={{ marginTop: "1rem" }}>
        <h2 className="card-title">Leaderboard – {problem.title}</h2>
        <p className="card-subtitle">
          This is a local scoreboard. A backend can later store scores across all students.
        </p>
        {leaderboardEntries.length === 0 ? (
          <p className="problem-subtitle" style={{ marginTop: "0.4rem" }}>
            No completed attempts yet. Solve all 4 rounds to appear on the leaderboard.
          </p>
        ) : (
          <table className="leaderboard-table">
            <thead>
              <tr>
                <th>Rank</th>
                <th>Name</th>
                <th>Best time (s)</th>
              </tr>
            </thead>
            <tbody>
              {leaderboardEntries.map((e, idx) => (
                <tr key={e.name}>
                  <td>#{idx + 1}</td>
                  <td>{e.name}</td>
                  <td>{e.time.toFixed(1)}</td>
                </tr>
              ))}
            </tbody>
          </table>
        )}
      </div>
    </div>
  );
}
