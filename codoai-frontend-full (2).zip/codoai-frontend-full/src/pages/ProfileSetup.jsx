import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function ProfileSetup({ onComplete, existing }) {
  const [name, setName] = useState(existing?.name ?? "");
  const [level, setLevel] = useState(existing?.level ?? "beginner");
  const [preferred, setPreferred] = useState(existing?.preferredLanguage ?? "python");
  const [goals, setGoals] = useState(existing?.goals ?? "");
  const [topics, setTopics] = useState(existing?.preferredTopics ?? "");

  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!name.trim()) return;
    onComplete({
      ...(existing || {}),
      id: existing?.id ?? 1,
      name: name.trim(),
      level,
      preferredLanguage: preferred,
      goals,
      preferredTopics: topics
    });
    navigate("/dashboard");
  };

  return (
    <div className="center-page">
      <div className="profile-card">
        <h1>Set up your coding profile</h1>
        <p>
          This helps codoAI tune hints, difficulty, and recommendations for you.
        </p>
        <form onSubmit={handleSubmit} className="profile-form">
          <label>
            <span>Your display name</span>
            <input
              value={name}
              onChange={(e) => setName(e.target.value)}
              placeholder="e.g. Wesley"
            />
          </label>
          <label>
            <span>Skill level</span>
            <select value={level} onChange={(e) => setLevel(e.target.value)}>
              <option value="beginner">Beginner</option>
              <option value="intermediate">Intermediate</option>
              <option value="advanced">Advanced</option>
            </select>
          </label>
          <label>
            <span>Preferred language</span>
            <select
              value={preferred}
              onChange={(e) => setPreferred(e.target.value)}
            >
              <option value="python">Python</option>
              <option value="cpp">C++</option>
              <option value="java">Java</option>
            </select>
          </label>
          <label>
            <span>Coding preferences / goals</span>
            <textarea
              rows={3}
              value={goals}
              onChange={(e) => setGoals(e.target.value)}
              placeholder="e.g. Improve debugging skills, prepare for interviews..."
            />
          </label>
          <label>
            <span>Favourite topics (comma separated)</span>
            <input
              value={topics}
              onChange={(e) => setTopics(e.target.value)}
              placeholder="arrays, strings, recursion..."
            />
          </label>
          <button type="submit" className="primary-btn full">
            Save profile & go to dashboard
          </button>
        </form>
      </div>
    </div>
  );
}
