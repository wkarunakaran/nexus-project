import React, { useState } from "react";
import { useNavigate } from "react-router-dom";

export default function Login({ onLogin }) {
  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");
  const [error, setError] = useState("");
  const navigate = useNavigate();

  const handleSubmit = (e) => {
    e.preventDefault();
    if (!username.trim() || !password.trim()) {
      setError("Please enter both username and password.");
      return;
    }
    const isAdmin = username.trim().toLowerCase() === "admin";
    const user = {
      id: 1,
      name: username.trim(),
      level: "beginner",
      preferredLanguage: "python",
      isAdmin
    };
    onLogin(user);
    navigate("/profile-setup");
  };

  return (
    <div className="center-page">
      <div className="profile-card">
        <h1>Login to codoAI</h1>
        <p>Use a simple username and password to enter the platform.</p>
        <form onSubmit={handleSubmit} className="profile-form">
          <label>
            <span>Username</span>
            <input
              value={username}
              onChange={(e) => setUsername(e.target.value)}
              placeholder="e.g. wesley123"
            />
          </label>
          <label>
            <span>Password</span>
            <input
              type="password"
              value={password}
              onChange={(e) => setPassword(e.target.value)}
              placeholder="••••••••"
            />
          </label>
          {error && (
            <p style={{ color: "#fca5a5", fontSize: "0.8rem" }}>{error}</p>
          )}
          <button type="submit" className="primary-btn full">
            Login
          </button>
        </form>
      </div>
    </div>
  );
}
