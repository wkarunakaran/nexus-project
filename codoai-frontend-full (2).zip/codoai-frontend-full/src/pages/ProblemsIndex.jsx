import React from "react";
import ProblemList from "../components/ProblemList";

export default function ProblemsIndex({ problems, attempts, currentLanguage }) {
  return (
    <div className="page">
      <ProblemList
        problems={problems}
        attempts={attempts}
        currentLanguage={currentLanguage}
      />
    </div>
  );
}
