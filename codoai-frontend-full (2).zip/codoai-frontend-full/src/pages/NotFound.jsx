import React from "react";
import { Link } from "react-router-dom";

export default function NotFound() {
  return (
    <div className="center-page">
      <div className="card">
        <h1>Page not found</h1>
        <p>Looks like this route doesn't exist in codoAI.</p>
        <Link to="/" className="primary-btn">
          Go back home
        </Link>
      </div>
    </div>
  );
}
