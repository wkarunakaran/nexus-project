import React from "react";
import { Link } from "react-router-dom";

export default function Landing() {
  return (
    <div className="landing">
      <div className="landing-hero">
        <div className="hero-text">
          <h1>
            Practice coding <span className="accent">the smart way</span> with{" "}
            <span className="logo-text">codoAI</span>.
          </h1>
          <p>
            Learn by typing, debugging, recalling from memory, and passing real test
            cases. Colorful progress, AI-guided hints, and support for Python, C++,
            and Java.
          </p>
          <div className="hero-actions">
            <Link to="/login" className="primary-btn large">
              Login with username
            </Link>
            <Link to="/profile-setup" className="ghost-btn large">
              Setup your profile
            </Link>
          </div>
          <div className="hero-tags">
            <span>Type → Debug → Blind → Test</span>
            <span>Python • C++ • Java</span>
            <span>Built for students</span>
          </div>
        </div>
        <div className="hero-visual">
          <div className="glass-card">
            <div className="glass-header">
              <span>Round progress</span>
              <span>R1 • R2 • R3 • R4</span>
            </div>
            <div className="glass-bars">
              <div className="glass-bar b1"></div>
              <div className="glass-bar b2"></div>
              <div className="glass-bar b3"></div>
              <div className="glass-bar b4"></div>
            </div>
            <div className="glass-footer">
              <span>AI recommendations</span>
              <span className="pill">Every 2 minutes</span>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
