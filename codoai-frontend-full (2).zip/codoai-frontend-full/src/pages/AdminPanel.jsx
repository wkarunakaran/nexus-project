import React, { useState } from "react";
import { MOCK_PROBLEMS } from "../data/mockProblems";

export default function AdminPanel({ problems, setProblems }) {
  const [title, setTitle] = useState("");
  const [difficulty, setDifficulty] = useState("Easy");
  const [topics, setTopics] = useState("");
  const [videoUrl, setVideoUrl] = useState("");

  const handleAdd = (e) => {
    e.preventDefault();
    if (!title.trim()) return;
    const nextId = problems.length
      ? Math.max(...problems.map((p) => p.id)) + 1
      : MOCK_PROBLEMS.length + 1;
    const newProblem = {
      id: nextId,
      title: title.trim(),
      difficulty,
      topics: topics
        .split(",")
        .map((t) => t.trim())
        .filter(Boolean),
      videoUrl: videoUrl || "https://example.com",
      referenceCode: {
        python: "# TODO: add Python reference code",
        java: "// TODO: add Java reference code",
        cpp: "// TODO: add C++ reference code"
      },
      explanations: {
        python: ["Explanation for Python will go here."],
        java: ["Explanation for Java will go here."],
        cpp: ["Explanation for C++ will go here."]
      },
      sampleTests: [{ id: 1, input: "", expected: "" }]
    };
    setProblems([...problems, newProblem]);
    setTitle("");
    setDifficulty("Easy");
    setTopics("");
    setVideoUrl("");
    alert("Problem added for students to view.");
  };

  return (
    <div className="page">
      <div className="card">
        <h1 className="card-title">Admin panel – Manage problems</h1>
        <p className="card-subtitle">
          Add new questions that students can see in the Problems list.
        </p>
        <form
          onSubmit={handleAdd}
          className="profile-form"
          style={{ marginTop: "0.8rem" }}
        >
          <label>
            <span>Problem title</span>
            <input
              value={title}
              onChange={(e) => setTitle(e.target.value)}
              placeholder="e.g. Check Prime Number"
            />
          </label>
          <label>
            <span>Difficulty</span>
            <select
              value={difficulty}
              onChange={(e) => setDifficulty(e.target.value)}
            >
              <option value="Easy">Easy</option>
              <option value="Medium">Medium</option>
              <option value="Hard">Hard</option>
            </select>
          </label>
          <label>
            <span>Topics (comma separated)</span>
            <input
              value={topics}
              onChange={(e) => setTopics(e.target.value)}
              placeholder="loops, conditions, arrays..."
            />
          </label>
          <label>
            <span>Learning video URL</span>
            <input
              value={videoUrl}
              onChange={(e) => setVideoUrl(e.target.value)}
              placeholder="https://..."
            />
          </label>
          <button type="submit" className="primary-btn full">
            Add problem
          </button>
        </form>
      </div>
      <div className="card" style={{ marginTop: "1rem" }}>
        <h2 className="card-title">Existing problems ({problems.length})</h2>
        <ul className="profile-problem-list">
          {problems.map((p) => (
            <li key={p.id} className="profile-problem-item">
              <div>
                <div className="profile-problem-title">
                  #{p.id} – {p.title}
                </div>
                <div className="profile-problem-meta">
                  Difficulty:{" "}
                  <span className={`difficulty ${p.difficulty.toLowerCase()}`}>
                    {p.difficulty}
                  </span>
                  {" • "}Topics: {p.topics.join(", ")}
                </div>
              </div>
            </li>
          ))}
        </ul>
      </div>
    </div>
  );
}
