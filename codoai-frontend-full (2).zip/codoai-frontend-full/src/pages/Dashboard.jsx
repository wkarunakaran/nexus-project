import React from "react";
import { Link } from "react-router-dom";
import ProblemList from "../components/ProblemList";
import ProgressBar from "../components/ProgressBar";

export default function Dashboard({ user, problems, attempts, currentLanguage }) {
  const totalProblems = problems.length;
  const completedCount = problems.filter((p) => {
    const key = `${p.id}_${currentLanguage}`;
    return attempts[key]?.finalCompleted;
  }).length;
  const completionPercent = totalProblems
    ? (completedCount / totalProblems) * 100
    : 0;

  return (
    <div className="page">
      <div className="grid-two">
        <div className="card highlight">
          <h1 className="hero-heading">
            Hey {user?.name || "coder"}, ready to{" "}
            <span className="accent">level up</span>?
          </h1>
          <p className="hero-subtext">
            Solve problems step-by-step, watch learning videos, and let AI guide
            you during blind typing and debugging rounds across Python, C++, and Java.
          </p>
          <div className="stats-row">
            <div className="stat-card">
              <div className="stat-label">Problems completed</div>
              <div className="stat-value">
                {completedCount} / {totalProblems}
              </div>
              <ProgressBar value={completionPercent} />
            </div>
            <div className="stat-card">
              <div className="stat-label">Current language</div>
              <div className="stat-value">{currentLanguage.toUpperCase()}</div>
              <p className="stat-extra">
                Switch language in the top-right to practice Python / C++ / Java.
              </p>
            </div>
          </div>
          <div className="cta-row">
            <Link to="/problems" className="primary-btn large">
              Start solving problems
            </Link>
            <Link to="/profile" className="ghost-btn">
              View your profile
            </Link>
          </div>
        </div>
        <ProblemList
          problems={problems}
          attempts={attempts}
          currentLanguage={currentLanguage}
        />
      </div>
    </div>
  );
}
